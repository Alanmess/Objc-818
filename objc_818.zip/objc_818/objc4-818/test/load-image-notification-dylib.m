#import "test.h"

#import <Foundation/Foundation.h>

@interface CLASSNAME: NSObject @end
@implementation CLASSNAME @end

