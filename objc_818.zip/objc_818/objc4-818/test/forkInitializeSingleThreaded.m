/*
TEST_RUN_OUTPUT
OK: forkInitialize\.m
OK: forkInitialize\.m
END
*/
#define SINGLETHREADED 1
#include "forkInitialize.m"
