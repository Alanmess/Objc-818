//
//  HQPerson.h
//  HQObjc
//
//  Created by Qiong Huang on 2021/1/20.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface HQPerson : NSObject

- (void)say;

- (void)eat;

- (void)walk;

@end

NS_ASSUME_NONNULL_END
