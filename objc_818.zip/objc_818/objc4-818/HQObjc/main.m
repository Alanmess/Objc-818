//
//  main.m
//  HQObjc
//
//  Created by Qiong Huang on 2021/1/20.
//

#import <Foundation/Foundation.h>
#import "HQPerson.h"

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        // insert code here...
        
        HQPerson *object1 = [HQPerson new];
        HQPerson *object2 = [HQPerson new];
        NSLog(@"==>obj1:%@", object1);
        NSLog(@"==>obj2:%@", object2);
        
        __weak id wObject = object1;
        NSLog(@"==>wObj1:%@", wObject);
        wObject = object2;
        NSLog(@"==>wObj2:%@", wObject);

//        HQPerson *man = [[HQPerson alloc] init];
//        [man say];
//        [man eat];
//        [man walk];
    }
    return 0;
}
