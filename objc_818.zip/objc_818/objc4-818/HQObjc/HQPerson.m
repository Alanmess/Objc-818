//
//  HQPerson.m
//  HQObjc
//
//  Created by Qiong Huang on 2021/1/20.
//

#import "HQPerson.h"

@implementation HQPerson

- (void)say {
    NSLog(@"man say something");
    
    NSDictionary *dic = @{@"si" : @"a"};
    [dic enumerateKeysAndObjectsUsingBlock:^(id  _Nonnull key, id  _Nonnull obj, BOOL * _Nonnull stop) {
            
    }];
}

- (void)eat {
    NSLog(@"man eat something");
}

- (void)walk {
    NSLog(@"man walk");
}

@end
